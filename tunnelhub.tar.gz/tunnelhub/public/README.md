## Update 2021-Feb-28 -- Added SSH Settings and Improve transition speed

### Need to change:
	 - Line 73  (SSH Log AJAX)
	 - Line 389 (Clear SSH Log AJAX)
	 - Line 510 (Load Saved SSH Settings AJAX)
	 - Line 732 (Save SSH Settings)
## Update 2021-Feb-24 -- Online Update and Auto Recon FRONT END UPDATE

### Need to change:
	 - Line 53  (Reconnect Status (Check or no))
	 - Line 73  (Auto Recon Log AJAX)
	 - Line 124 (Auto Reconnect Yes or No)
	 - Line 406 (Auto Recon Clear Logs AJAX)


